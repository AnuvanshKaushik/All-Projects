from flask import Flask,request,render_template
import numpy as np
import pickle


app= Flask(__name__,template_folder=r"C:\Users\kaush\Downloads\Anuvansh\WEB_DEVELOPEMENT\Bakloli",static_folder=r"C:\Users\kaush\Downloads\Anuvansh\WEB_DEVELOPEMENT\Bakloli") #Creating a Flask class object
# Load your pre-trained model

with open('model.pkl', 'rb') as file:
    RFG = pickle.load(file)

@app.route('/') 
def home():  
    return render_template('template/BL.html');  

@app.route('/predict', methods=['POST'])
def predict():
    store_id = int(request.form['store_id'])
    sku_id = int(request.form['sku_id'])
    total_price = float(request.form['total_price'])
    base_price = float(request.form['base_price'])
    is_featured_sku = int(request.form['is_featured_sku'])
    is_display_sku = int(request.form['is_display_sku'])

    # Create the feature array for prediction
    features = np.array([[store_id, sku_id, total_price, base_price, is_featured_sku, is_display_sku]])
    prediction = RFG.predict(features)
    
    return render_template('template/BL.html', prediction_text=f'Predicted Units Sold: {prediction[0]:}')

#   # Handle potential errors (e.g., empty query)
#     return render_template('HTML/ChatGpt.html', content=get_content(user_query))


if __name__ =='__main__':  
    app.run(debug=True)